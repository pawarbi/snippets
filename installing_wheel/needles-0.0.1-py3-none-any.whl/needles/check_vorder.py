def get(table_name_path):
    '''
    Author: Sandeep Pawar | fabric.guru |  Jun 6, 2023

    Provide table_name_path as '//lakehouse/default/Tables/<table_name>'
    If the Delta table is V-ordered, returns true; otherwise, false.

    You must first mount the lakehouse to use the local filesystem API.
    '''
    import os 

    if not os.path.exists(table_name_path):
        print(f'{os.path.basename(table_name_path)} does not exist')
        result = None  # Initialize the variable with a default value

    else:
        import pyarrow.dataset as ds
        schema = ds.dataset(table_name_path).schema.metadata
        is_vorder = any(b'vorder' in key for key in schema.keys())
        if is_vorder:
            result = str(schema[b'com.microsoft.parquet.vorder.enabled'])
        else:
            result = "Table is not V-ordered"

    return result